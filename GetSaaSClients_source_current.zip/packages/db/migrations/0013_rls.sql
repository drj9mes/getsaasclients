GRANT USAGE ON SCHEMA app TO saasclients_api,saasclients_auth,saasclients_worker,saasclients_admin,saasclients_public;

-- Workspace itself uses id, not workspace_id.
ALTER TABLE app.workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.workspaces FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS workspaces_api_tenant ON app.workspaces;
CREATE POLICY workspaces_api_tenant ON app.workspaces TO saasclients_api
  USING (id = app.current_workspace_id())
  WITH CHECK (id = app.current_workspace_id());
-- User-scoped bootstrap/listing path before a workspace context exists.
DROP POLICY IF EXISTS workspaces_api_creator_select ON app.workspaces;
CREATE POLICY workspaces_api_creator_select ON app.workspaces FOR SELECT TO saasclients_api
  USING (created_by_user_id = app.current_user_id());
DROP POLICY IF EXISTS workspaces_api_bootstrap_insert ON app.workspaces;
CREATE POLICY workspaces_api_bootstrap_insert ON app.workspaces FOR INSERT TO saasclients_api
  WITH CHECK (created_by_user_id = app.current_user_id());
DROP POLICY IF EXISTS workspaces_worker_all ON app.workspaces;
CREATE POLICY workspaces_worker_all ON app.workspaces TO saasclients_worker USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS workspaces_admin_all ON app.workspaces;
CREATE POLICY workspaces_admin_all ON app.workspaces TO saasclients_admin USING (true) WITH CHECK (true);

DO $$
DECLARE table_name text;
BEGIN
  FOREACH table_name IN ARRAY ARRAY[
    'workspace_members','products','product_versions','icp_profiles','crawl_runs','crawl_jobs',
    'opportunities','feedback_labels','pipeline_events','revenue_attributions','source_performance',
    'public_profiles','stories','deletion_requests','opportunity_feed_read','product_summary_read',
    'acquisition_funnel_read'
  ]
  LOOP
    EXECUTE format('ALTER TABLE app.%I ENABLE ROW LEVEL SECURITY', table_name);
    EXECUTE format('ALTER TABLE app.%I FORCE ROW LEVEL SECURITY', table_name);
    BEGIN
      EXECUTE format(
        'CREATE POLICY %I_api_tenant ON app.%I TO saasclients_api USING (workspace_id = app.current_workspace_id()) WITH CHECK (workspace_id = app.current_workspace_id())',
        table_name, table_name
      );
    EXCEPTION WHEN duplicate_object THEN NULL; END;
    BEGIN
      EXECUTE format('CREATE POLICY %I_worker_all ON app.%I TO saasclients_worker USING (true) WITH CHECK (true)', table_name, table_name);
    EXCEPTION WHEN duplicate_object THEN NULL; END;
    BEGIN
      EXECUTE format('CREATE POLICY %I_admin_all ON app.%I TO saasclients_admin USING (true) WITH CHECK (true)', table_name, table_name);
    EXCEPTION WHEN duplicate_object THEN NULL; END;
  END LOOP;
END $$;

-- A signed-in user may list their own memberships before choosing a workspace and may create the owner row for a workspace they just created.
DROP POLICY IF EXISTS workspace_members_api_self_select ON app.workspace_members;
CREATE POLICY workspace_members_api_self_select ON app.workspace_members FOR SELECT TO saasclients_api
  USING (user_id = app.current_user_id());
DROP POLICY IF EXISTS workspace_members_api_bootstrap_insert ON app.workspace_members;
CREATE POLICY workspace_members_api_bootstrap_insert ON app.workspace_members FOR INSERT TO saasclients_api
  WITH CHECK (user_id = app.current_user_id() AND role = 'owner' AND status = 'active' AND EXISTS (SELECT 1 FROM app.workspaces w WHERE w.id = workspace_id AND w.created_by_user_id = app.current_user_id()));

ALTER TABLE app.verified_facts ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.verified_facts FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS verified_facts_api_read ON app.verified_facts;
CREATE POLICY verified_facts_api_read ON app.verified_facts FOR SELECT TO saasclients_api
  USING (workspace_id IS NULL OR workspace_id = app.current_workspace_id());
DROP POLICY IF EXISTS verified_facts_api_write ON app.verified_facts;
CREATE POLICY verified_facts_api_write ON app.verified_facts FOR ALL TO saasclients_api
  USING (workspace_id = app.current_workspace_id())
  WITH CHECK (workspace_id = app.current_workspace_id());
DROP POLICY IF EXISTS verified_facts_worker_all ON app.verified_facts;
CREATE POLICY verified_facts_worker_all ON app.verified_facts TO saasclients_worker USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS verified_facts_admin_all ON app.verified_facts;
CREATE POLICY verified_facts_admin_all ON app.verified_facts TO saasclients_admin USING (true) WITH CHECK (true);

ALTER TABLE app.embeddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.embeddings FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS embeddings_worker_all ON app.embeddings;
CREATE POLICY embeddings_worker_all ON app.embeddings TO saasclients_worker USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS embeddings_admin_all ON app.embeddings;
CREATE POLICY embeddings_admin_all ON app.embeddings TO saasclients_admin USING (true) WITH CHECK (true);

ALTER TABLE app.audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.audit_events FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS audit_api_tenant_read ON app.audit_events;
CREATE POLICY audit_api_tenant_read ON app.audit_events FOR SELECT TO saasclients_api
  USING (workspace_id = app.current_workspace_id());
DROP POLICY IF EXISTS audit_worker_insert ON app.audit_events;
CREATE POLICY audit_worker_insert ON app.audit_events FOR INSERT TO saasclients_worker WITH CHECK (true);
DROP POLICY IF EXISTS audit_admin_all ON app.audit_events;
CREATE POLICY audit_admin_all ON app.audit_events TO saasclients_admin USING (true) WITH CHECK (true);

ALTER TABLE app.public_profile_read ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.public_profile_read FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS public_profile_read_api_tenant ON app.public_profile_read;
CREATE POLICY public_profile_read_api_tenant ON app.public_profile_read FOR SELECT TO saasclients_api
  USING (workspace_id = app.current_workspace_id());
-- The Express public BFF intentionally uses the API pool; this SELECT-only policy exposes published rows only.
DROP POLICY IF EXISTS public_profile_read_api_published ON app.public_profile_read;
CREATE POLICY public_profile_read_api_published ON app.public_profile_read FOR SELECT TO saasclients_api
  USING (status = 'published' AND published_at IS NOT NULL);
DROP POLICY IF EXISTS public_profile_read_public ON app.public_profile_read;
CREATE POLICY public_profile_read_public ON app.public_profile_read FOR SELECT TO saasclients_public
  USING (status = 'published' AND published_at IS NOT NULL);
DROP POLICY IF EXISTS public_profile_read_worker_all ON app.public_profile_read;
CREATE POLICY public_profile_read_worker_all ON app.public_profile_read TO saasclients_worker USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS public_profile_read_admin_all ON app.public_profile_read;
CREATE POLICY public_profile_read_admin_all ON app.public_profile_read TO saasclients_admin USING (true) WITH CHECK (true);

-- Public acquisition stories are founder-approved before publication. The SELECT-only policy makes only published stories visible without tenant context.
DROP POLICY IF EXISTS stories_api_published ON app.stories;
CREATE POLICY stories_api_published ON app.stories FOR SELECT TO saasclients_api
  USING (status = 'published' AND published_at IS NOT NULL);

-- API: tenant product/CRM data plus durable receipt insertion. Outbox remains write-only to the API role.
GRANT SELECT,INSERT,UPDATE,DELETE ON
  app.workspaces,app.workspace_members,app.products,app.product_versions,app.icp_profiles,
  app.opportunities,app.feedback_labels,app.pipeline_events,app.revenue_attributions,
  app.public_profiles,app.stories,app.deletion_requests
TO saasclients_api;
GRANT SELECT,INSERT ON app.crawl_jobs TO saasclients_api;
GRANT INSERT ON app.outbox_events TO saasclients_api;
GRANT SELECT ON
  app.opportunity_feed_read,app.product_summary_read,app.acquisition_funnel_read,
  app.communities,app.conversations,app.messages,app.signals,app.signal_evidence,
  app.sources,app.source_status_read,app.verified_facts,app.public_profile_read
TO saasclients_api;

GRANT SELECT,INSERT,UPDATE,DELETE ON app.users,app.auth_accounts,app.auth_sessions,app.auth_verification_tokens TO saasclients_auth;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA app TO saasclients_worker,saasclients_admin;
GRANT SELECT ON app.public_profile_read TO saasclients_public;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA app TO saasclients_worker,saasclients_admin,saasclients_api,saasclients_auth;
