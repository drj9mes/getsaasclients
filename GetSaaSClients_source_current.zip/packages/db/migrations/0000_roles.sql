DO $$ BEGIN
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_api') THEN CREATE ROLE saasclients_api NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_auth') THEN CREATE ROLE saasclients_auth NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_worker') THEN CREATE ROLE saasclients_worker NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_admin') THEN CREATE ROLE saasclients_admin NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_public') THEN CREATE ROLE saasclients_public NOLOGIN NOBYPASSRLS; END IF;
END $$;
