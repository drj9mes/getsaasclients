import { parentPort } from 'node:worker_threads';
import { deterministicMatch } from '@saasclients/matching';
import type { ProductAnalysis, Signal } from '@saasclients/contracts';

type Task={id:number;type:'match';payload:{product:ProductAnalysis;signal:Signal;sourceId:string;sourceTrust:number;reachability:number}};
if(!parentPort) throw new Error('CPU_WORKER_PARENT_PORT_REQUIRED');
parentPort.on('message',(task:Task)=>{
  try{
    if(task.type!=='match') throw new Error('UNSUPPORTED_CPU_TASK');
    const result=deterministicMatch(task.payload.product,task.payload.signal,{sourceId:task.payload.sourceId,sourceTrust:task.payload.sourceTrust,reachability:task.payload.reachability});
    parentPort!.postMessage({id:task.id,ok:true,result});
  }catch(error){parentPort!.postMessage({id:task.id,ok:false,error:error instanceof Error?error.message:String(error)})}
});
