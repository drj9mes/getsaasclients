import dns from 'node:dns/promises';
import net from 'node:net';
import crypto from 'node:crypto';
import { CheerioCrawler, PlaywrightCrawler } from 'crawlee';
import type { AccessClass, NormalizedConversation, OriginClient } from '@saasclients/contracts';

export interface PolicyDecision { allowed: boolean; reason: string; method?: 'api'|'feed'|'http'|'browser' }
export interface SourceHealth { ok: boolean; status: 'healthy'|'degraded'|'blocked'; message?: string }
export interface SourceAdapter<TCursor = unknown, TRaw = unknown> {
  readonly id: string;
  readonly accessClass: AccessClass;
  readonly capabilities: { api:boolean; rss:boolean; html:boolean; browser:boolean; backfill:boolean; deletions:boolean; externalApproval:boolean; commercialUse:'allowed'|'forbidden'|'unknown' };
  readonly pricing: { mode:'free'|'paid'|'unknown'; hardMonthlyCapUsd: 0 };
  validateConfig(config: unknown): Promise<{ok:boolean;errors:string[]}>;
  reviewPolicy(): Promise<PolicyDecision>;
  discover(input:{query?:string;since?:Date}): AsyncIterable<{externalId:string;cursor?:TCursor}>;
  fetchPage(cursor:TCursor, context:{signal:AbortSignal}): Promise<{items:TRaw[];nextCursor?:TCursor;retryAfterSeconds?:number}>;
  normalize(raw:TRaw): Promise<NormalizedConversation[]>;
  health(): Promise<SourceHealth>;
}

export class SourceRegistry {
  private readonly map = new Map<string, SourceAdapter>();
  register(adapter:SourceAdapter) {
    if (adapter.pricing.hardMonthlyCapUsd !== 0) throw new Error('PAID_SOURCE_FORBIDDEN');
    if (this.map.has(adapter.id)) throw new Error(`duplicate adapter ${adapter.id}`);
    this.map.set(adapter.id, adapter);
    return this;
  }
  get(id:string) { return this.map.get(id); }
  list() { return [...this.map.values()]; }
}
export const sourceRegistry = new SourceRegistry();

export function isPrivateAddress(ip:string) {
  if (net.isIP(ip) === 4) {
    const parts = ip.split('.').map(Number);
    const a = parts[0] ?? -1, b = parts[1] ?? -1;
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a >= 224;
  }
  if (net.isIP(ip) === 6) {
    const x = ip.toLowerCase();
    return x === '::1' || x === '::' || x.startsWith('fe80:') || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('ff');
  }
  return true;
}

export async function assertPublicHttpUrl(input:string) {
  const url = new URL(input);
  if (!['http:','https:'].includes(url.protocol)) throw new Error('UNSAFE_PROTOCOL');
  if (url.username || url.password) throw new Error('URL_CREDENTIALS_FORBIDDEN');
  const addresses = await dns.lookup(url.hostname, { all:true });
  if (!addresses.length || addresses.some(x => isPrivateAddress(x.address))) throw new Error('SSRF_PRIVATE_ADDRESS');
  return url;
}

export async function safeFetch(
  input:string,
  init:RequestInit = {},
  limits = { redirects:5, timeoutMs:30000, maxBytes:10*1024*1024 },
) {
  let url = await assertPublicHttpUrl(input);
  for (let i=0; i<=limits.redirects; i++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), limits.timeoutMs);
    const upstream = init.signal;
    const onAbort = () => controller.abort();
    upstream?.addEventListener('abort', onAbort, { once:true });
    try {
      const response = await fetch(url, { ...init, redirect:'manual', signal:controller.signal });
      if ([301,302,303,307,308].includes(response.status)) {
        const location = response.headers.get('location');
        if (!location) throw new Error('REDIRECT_WITHOUT_LOCATION');
        url = await assertPublicHttpUrl(new URL(location, url).toString());
        continue;
      }
      if (response.status === 429) {
        const error = new Error('RATE_LIMITED') as Error & { retryAfter?:string };
        const retryAfter = response.headers.get('retry-after');
        if (retryAfter !== null) error.retryAfter = retryAfter;
        throw error;
      }
      const declared = Number(response.headers.get('content-length') ?? 0);
      if (declared > limits.maxBytes) throw new Error('RESPONSE_TOO_LARGE');
      return response;
    } finally {
      clearTimeout(timeout);
      upstream?.removeEventListener('abort', onAbort);
    }
  }
  throw new Error('TOO_MANY_REDIRECTS');
}

export function canonicalUrl(input:string) {
  const url = new URL(input);
  url.hash = '';
  for (const key of ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid']) url.searchParams.delete(key);
  url.hostname = url.hostname.toLowerCase();
  if ((url.protocol === 'https:' && url.port === '443') || (url.protocol === 'http:' && url.port === '80')) url.port = '';
  return url.toString();
}
export function hashUrl(input:string) { return crypto.createHash('sha256').update(canonicalUrl(input)).digest('hex'); }
export function requireGatedAuthorization(input:{enabled:boolean;hasCredential:boolean;authorizationActive:boolean;healthScopesOk:boolean}) {
  return input.enabled && input.hasCredential && input.authorizationActive && input.healthScopesOk;
}
export function backoffDelay(attempt:number, retryAfterSeconds?:number) {
  if (retryAfterSeconds !== undefined) return Math.min(3_600_000, Math.max(0, retryAfterSeconds) * 1000);
  const base = Math.min(300_000, 1000 * 2 ** Math.min(attempt, 8));
  return Math.floor(base * (0.75 + Math.random() * 0.5));
}

function parseRobots(text:string, userAgent:string) {
  const ua = userAgent.toLowerCase();
  const groups:Array<{agents:string[];allow:string[];disallow:string[]}> = [];
  let current:{agents:string[];allow:string[];disallow:string[]} | undefined;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, '').trim();
    if (!line) continue;
    const [name,...rest] = line.split(':');
    const value = rest.join(':').trim();
    if (name?.trim().toLowerCase() === 'user-agent') {
      if (!current || current.allow.length || current.disallow.length) { current={agents:[],allow:[],disallow:[]}; groups.push(current); }
      current.agents.push(value.toLowerCase());
    } else if (current && name?.trim().toLowerCase() === 'allow') current.allow.push(value);
    else if (current && name?.trim().toLowerCase() === 'disallow') current.disallow.push(value);
  }
  const matching = groups.filter(g => g.agents.some(a => a === '*' || ua.includes(a)));
  return matching;
}

export async function robotsAllows(input:string, userAgent='GetSaaSClientsBot') {
  const url = await assertPublicHttpUrl(input);
  const robotsUrl = `${url.protocol}//${url.host}/robots.txt`;
  try {
    const response = await safeFetch(robotsUrl, { headers:{'user-agent':userAgent} }, { redirects:3, timeoutMs:10000, maxBytes:512*1024 });
    if (response.status === 404) return true;
    if (!response.ok) return false;
    const groups = parseRobots(await response.text(), userAgent);
    const path = `${url.pathname}${url.search}`;
    let best:{allowed:boolean;length:number}|undefined;
    for (const group of groups) {
      for (const rule of group.allow) if (rule && path.startsWith(rule) && (!best || rule.length > best.length)) best={allowed:true,length:rule.length};
      for (const rule of group.disallow) if (rule && path.startsWith(rule) && (!best || rule.length > best.length)) best={allowed:false,length:rule.length};
    }
    return best?.allowed ?? true;
  } catch { return false; }
}

export type HtmlPage = { url:string; title:string; text:string; links:string[]; rendered:boolean };
export async function crawlHtmlPages(
  urls:string[],
  options:{ maxPages?:number; maxConcurrency?:number; browserFallback?:boolean; userAgent?:string } = {},
) {
  const maxPages = Math.max(1, Math.min(options.maxPages ?? 15, 100));
  const userAgent = options.userAgent ?? 'GetSaaSClientsBot/0.1 (+https://getsaasclients.com)';
  const approved:string[]=[];
  for (const url of urls) if (approved.length < maxPages && await robotsAllows(url,userAgent)) approved.push((await assertPublicHttpUrl(url)).toString());
  const pages:HtmlPage[]=[];
  if (!approved.length) return pages;
  const httpCrawler = new CheerioCrawler({
    maxConcurrency:Math.max(1, Math.min(options.maxConcurrency ?? 4, 16)),
    maxRequestsPerCrawl:maxPages,
    requestHandler:async({$,request}) => {
      const links:string[]=[];
      $('a[href]').each((_i,element) => {
        const href=$(element).attr('href');
        if (!href) return;
        try { links.push(new URL(href, request.loadedUrl ?? request.url).toString()); } catch {}
      });
      pages.push({
        url:request.loadedUrl ?? request.url,
        title:$('title').first().text().trim(),
        text:$('body').text().replace(/\s+/g,' ').trim().slice(0,250_000),
        links:[...new Set(links)].slice(0,500),
        rendered:false,
      });
    },
    failedRequestHandler:async()=>{},
  });
  await httpCrawler.run(approved.map(url => ({ url, headers:{'user-agent':userAgent} })));

  if (options.browserFallback) {
    const weak=approved.filter(url => !pages.some(p => p.url === url && p.text.length >= 500));
    if (weak.length) {
      const browserCrawler = new PlaywrightCrawler({
        maxConcurrency:1,
        maxRequestsPerCrawl:Math.min(weak.length, maxPages),
        requestHandlerTimeoutSecs:30,
        requestHandler:async({page,request}) => {
          const title=await page.title();
          const text=(await page.locator('body').innerText().catch(()=>'' as string)).replace(/\s+/g,' ').trim().slice(0,250_000);
          const links=await page.locator('a[href]').evaluateAll(nodes => nodes.slice(0,500).map(n => (n as HTMLAnchorElement).href)).catch(()=>[] as string[]);
          pages.push({url:request.loadedUrl ?? request.url,title,text,links:[...new Set(links)],rendered:true});
        },
        failedRequestHandler:async()=>{},
      });
      await browserCrawler.run(weak);
    }
  }
  const dedup = new Map<string,HtmlPage>();
  for (const page of pages) dedup.set(canonicalUrl(page.url), page);
  return [...dedup.values()].slice(0,maxPages);
}

export type CrawlEvent = { type:'discovered'|'fetched'|'normalized'|'qualified'|'failed'; sourceId:string; client:OriginClient; at:string; data?:Record<string,unknown> };

export function createCrawler(registry=sourceRegistry) {
  return {
    registry,
    async sample(id:string, limit=100, query?:string) {
      const adapter=registry.get(id);
      if (!adapter) throw new Error('SOURCE_NOT_FOUND');
      const policy=await adapter.reviewPolicy();
      if (!policy.allowed) throw new Error(`POLICY_BLOCKED:${policy.reason}`);
      const out:NormalizedConversation[]=[];
      const seenCursor=new Set<string>();
      for await (const target of adapter.discover(query === undefined ? {} : {query})) {
        let cursor=(target.cursor ?? target.externalId) as never;
        for (let pageNo=0; pageNo<100 && out.length<limit; pageNo++) {
          const cursorKey=JSON.stringify(cursor);
          if (seenCursor.has(`${target.externalId}:${cursorKey}`)) break;
          seenCursor.add(`${target.externalId}:${cursorKey}`);
          const controller=new AbortController();
          const page=await adapter.fetchPage(cursor,{signal:controller.signal});
          for (const raw of page.items) {
            out.push(...await adapter.normalize(raw));
            if (out.length>=limit) break;
          }
          if (!page.nextCursor || out.length>=limit) break;
          cursor=page.nextCursor as never;
          if (page.retryAfterSeconds !== undefined) { const retryAfterSeconds=page.retryAfterSeconds; await new Promise(r=>setTimeout(r,Math.min(retryAfterSeconds*1000,30_000))); }
        }
        if (out.length>=limit) break;
      }
      return out.slice(0,limit);
    },
  };
}
