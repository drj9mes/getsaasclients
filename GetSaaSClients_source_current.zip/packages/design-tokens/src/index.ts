export const tokens = {
  color: { signalOrange:'#FF6A3D', proofGreen:'#168A5B', evidenceAmber:'#D18B00', riskRed:'#D64545', ink:'#111111', paper:'#FFFDF7', slate:'#6B7280' },
  radius: { sm:'8px', md:'12px' },
  font: { heading:'"Space Mono", ui-monospace, monospace', body:'Inter, system-ui, sans-serif' }
} as const;
export type SemanticState='Discovered'|'Fetched'|'Extracted'|'Qualified'|'Matched'|'Dismissed'|'Contacted'|'Replied'|'Trial'|'Won'|'Lost';
