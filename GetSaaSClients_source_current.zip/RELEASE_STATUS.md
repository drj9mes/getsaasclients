# Release status — 2026-08-31 build

This archive contains the complete MVP source implementation and release tooling. It deliberately distinguishes deterministic build readiness from real-world production certification.

## Passed in the construction environment

- TypeScript/TSX syntax gate.
- Static production-contract audit.
- Exactly 40 application truth tables + 5 read projections in migrations.
- Fixed 10-service Docker topology present.
- Source/security audit (no executable Reddit/Meta/X adapter, anti-circumvention guardrails present).
- Gate-B baseline metric fixture thresholds.
- Deterministic 100,000-arrival bounded-admission/coalescing model.

## Must run in an Internet/Docker-capable release environment

The construction sandbox cannot resolve/download the npm dependency graph and does not contain Docker/PostgreSQL. Therefore the following cannot honestly be marked green inside this sandbox and are automated/procedural in this repository:

1. generate and commit `pnpm-lock.yaml` from the official npm registry;
2. `pnpm install --frozen-lockfile`;
3. dependency-backed TypeScript typecheck, Vitest suites and Next/Express/worker production builds;
4. PostgreSQL 17/pgvector migrations, RLS/grant integrity and backup/restore;
5. composed API/web/worker smoke and live 100k-arrival gate;
6. low-rate live GitHub/HN/Stack Exchange/Forem/Bluesky/GitLab canaries;
7. live Gemini classifier/embedding/rerank with a temporary secret;
8. Google/GitHub OAuth and SMTP magic-link browser smoke;
9. 7-day soak and 30-day continuous local validation;
10. human double-annotation/Cohen-kappa Gate B completion;
11. commercial dogfood Gate 0: GetSaaSClients acquiring at least three paying/pilot customers for itself.

A release must not be described as fully production-certified until those environment/calendar/commercial gates are green. `.github/workflows/release.yml` and `live-validation.yml` provide the automated portion; the runbook defines the calendar gates.
