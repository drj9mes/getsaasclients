import{Router}from'express';
import{BoundedLRU,SingleFlight}from'@saasclients/runtime-control';
import{pool}from'../services/jobs.js';

export const publicRoutes=Router();
const cache=new BoundedLRU<string,unknown>(Number(process.env.PUBLIC_API_CACHE_MAX_ENTRIES??5000),Number(process.env.PUBLIC_API_CACHE_MAX_BYTES??32*1024*1024));
const flights=new SingleFlight<string,unknown>(Number(process.env.SINGLEFLIGHT_MAX_KEYS??2000));
async function cached<T>(key:string,ttlMs:number,load:()=>Promise<T>):Promise<T>{
  const hit=cache.get(key) as T|undefined;if(hit!==undefined)return hit;
  return flights.run(key,async()=>{const second=cache.get(key) as T|undefined;if(second!==undefined)return second;const value=await load();const json=JSON.stringify(value);cache.set(key,value,Buffer.byteLength(json),ttlMs);return value}) as Promise<T>;
}

publicRoutes.get('/public/auth-providers',(_req,res)=>res.set('Cache-Control','public, max-age=60').json({github:Boolean(process.env.GITHUB_CLIENT_ID&&process.env.GITHUB_CLIENT_SECRET),google:Boolean(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET),email:Boolean(process.env.BREVO_SMTP_USER&&process.env.BREVO_SMTP_PASSWORD)}));

publicRoutes.get('/public/saas/:slug',async(req,res)=>{
  const slug=String(req.params.slug??'').toLowerCase();
  const row=await cached(`saas:${slug}`,300_000,async()=>{const r=await pool.query(`SELECT slug,title,description,rendered_content,metadata,json_ld,published_at,canonical_path FROM app.public_profile_read WHERE slug=$1 AND status='published'`,[slug]);return r.rows[0]??null});
  if(!row)return res.status(404).json({type:'about:blank',title:'SaaS not found',status:404});
  res.set('Cache-Control','public, max-age=300, stale-while-revalidate=3600').json(row);
});
publicRoutes.get('/public/stories/:slug',async(req,res)=>{
  const slug=String(req.params.slug??'').toLowerCase();
  const row=await cached(`story:${slug}`,300_000,async()=>{const r=await pool.query(`SELECT slug,title,summary,body_markdown,evidence_refs,published_at FROM app.stories WHERE slug=$1 AND status='published'`,[slug]);return r.rows[0]??null});
  if(!row)return res.status(404).end();
  res.set('Cache-Control','public, max-age=300, stale-while-revalidate=3600').json(row);
});
publicRoutes.get('/public/sitemap',async(_req,res)=>{
  const data=await cached('sitemap',60_000,async()=>{const[p,s]=await Promise.all([pool.query(`SELECT canonical_path path,published_at updated FROM app.public_profile_read WHERE status='published'`),pool.query(`SELECT '/stories/'||slug path,published_at updated FROM app.stories WHERE status='published'`)]);return{items:[...p.rows,...s.rows]}});
  res.set('Cache-Control','public, max-age=60, stale-while-revalidate=300').json(data);
});
publicRoutes.get('/public/corpus-pulse',async(_req,res)=>{
  const data=await cached('corpus-pulse',30_000,async()=>{const r=await pool.query(`SELECT (SELECT count(*) FROM app.conversations WHERE deleted_at IS NULL) live_corpus,(SELECT count(*) FROM app.signals WHERE qualification_status='qualified' AND(expires_at IS NULL OR expires_at>now())) qualified_signals,(SELECT count(*) FROM app.sources WHERE status='active') sources_healthy,(SELECT count(*) FROM app.sources) sources_total`);return r.rows[0]});
  res.set('Cache-Control','public, max-age=60').json(data);
});
