import type{NextConfig}from'next';const config:NextConfig={output:'standalone',poweredByHeader:false,compress:true,experimental:{typedEnv:true}};export default config;
