'use client';
import { useState } from 'react';
const api=process.env.NEXT_PUBLIC_API_URL??'';
function lines(values:string[]|undefined){return (values??[]).join('\n')}
export function ProductEditor({product,workspaceId}:{product:any;workspaceId:string}){
  const[name,setName]=useState(String(product.name??''));
  const[summary,setSummary]=useState(String(product.summary??''));
  const[roles,setRoles]=useState(lines(product.roles));
  const[pains,setPains]=useState(lines(product.pains));
  const[intents,setIntents]=useState(lines(product.intents));
  const[msg,setMsg]=useState(''); const[saving,setSaving]=useState(false);
  const toList=(v:string)=>v.split(/\r?\n|,/).map(x=>x.trim()).filter(Boolean).slice(0,100);
  async function save(){
    setSaving(true);setMsg('Saving a new confirmed product version…');
    try{
      const r=await fetch(`${api}/api/v1/products/${product.id}`,{method:'PATCH',credentials:'include',headers:{'content-type':'application/json','x-workspace-id':workspaceId},body:JSON.stringify({name,summary,roles:toList(roles),pains:toList(pains),intents:toList(intents)})});
      const j=await r.json().catch(()=>({})); if(!r.ok)throw new Error(j.detail??j.title??'Save failed');
      setMsg('Saved. Future matching uses this founder-confirmed version.');
    }catch(e){setMsg(e instanceof Error?e.message:'Save failed')}finally{setSaving(false)}
  }
  return <div className="formgrid">
    <label>Product name<input value={name} onChange={e=>setName(e.target.value)} maxLength={180}/></label>
    <label>Summary<textarea value={summary} onChange={e=>setSummary(e.target.value)} rows={5} maxLength={5000}/></label>
    <div className="grid3">
      <label>Buyer roles<textarea value={roles} onChange={e=>setRoles(e.target.value)} rows={6} placeholder="Founder\nHead of growth"/></label>
      <label>Problems solved<textarea value={pains} onChange={e=>setPains(e.target.value)} rows={6} placeholder="Hard to find first customers"/></label>
      <label>Buying intents<textarea value={intents} onChange={e=>setIntents(e.target.value)} rows={6} placeholder="Looking for leads\nNeed first customers"/></label>
    </div>
    <div><button className="btn primary" disabled={saving||!name.trim()||!summary.trim()} onClick={save}>{saving?'Saving…':'Confirm analysis'}</button> {msg&&<span className="muted">{msg}</span>}</div>
  </div>
}
