import PgBoss from 'pg-boss';
import cron from 'node-cron';
import crypto from 'node:crypto';
import { createPool } from '@saasclients/db';
import { JsonlLogger } from '@saasclients/observability';
import { createCrawler } from '@saasclients/crawler';
import { sourceRegistry } from '@saasclients/source-adapters';
import { classifyDeterministically, quickSignalCandidate } from '@saasclients/extraction';
import { createAiProvider } from '@saasclients/ai';
import { ensureBuiltInSources, persistConversation, persistSignal } from './corpus.js';
import { prepareProductAnalysis, persistProductAnalysis } from './product.js';
import { matchProduct, closeMatchingPool } from './matcher.js';
import { refreshOpportunity, refreshProductSummary, refreshPublicProfile } from '@saasclients/read-models';
import type { ProductAnalysis, Signal } from '@saasclients/contracts';

const role=process.env.WORKER_ROLE??'jobs';
if(process.env.NODE_ENV==='production'&&process.env.AI_PROVIDER==='deterministic'&&process.env.SAASCLIENTS_RUNTIME_PROFILE!=='local-precision-7720') throw new Error('Deterministic AI is local-validation/CI-only; configure Gemini for the production VPS profile.');
const pool=createPool('worker');
const boss=new PgBoss({
  connectionString:process.env.DATABASE_PGBOSS_URL??process.env.DATABASE_WORKER_URL,
  schema:process.env.PG_BOSS_SCHEMA??'pgboss',
  deleteAfterSeconds:Number(process.env.PG_BOSS_COMPLETED_DELETE_AFTER_SECONDS??86400),
});
const log=new JsonlLogger(`worker-${role}`);
const ai=createAiProvider();
const crawler=createCrawler(sourceRegistry);
const client={type:'worker' as const,name:`worker-${role}`};

type Handler=(receiptId:string)=>Promise<Record<string,unknown>|void>;
const handlers=new Map<string,Handler>();

async function receiptPayload(id:string){
  const r=await pool.query(`SELECT payload,workspace_id,attempts_started,max_attempts FROM app.crawl_jobs WHERE id=$1`,[id]);
  if(!r.rowCount) throw new Error('RECEIPT_NOT_FOUND');
  return r.rows[0];
}

handlers.set('product.analyze',async id=>{
  const job=await receiptPayload(id);
  const prepared=await prepareProductAnalysis(job.payload);
  const c=await pool.connect();
  try{
    await c.query('BEGIN');
    const result=await persistProductAnalysis(c,job.payload,prepared);
    await c.query(`INSERT INTO app.outbox_events(event_key,aggregate_type,aggregate_id,event_type,payload,queue) VALUES($1,'public_profile',$2,'public_profile.changed',$3,'intelligence') ON CONFLICT(event_key) DO NOTHING`,[`public-profile:${result.publicProfileId}:${result.productVersionId}`,result.publicProfileId,{publicProfileId:result.publicProfileId}]);
    await c.query('COMMIT');
    return {productId:result.productId,productVersionId:result.productVersionId,pagesAnalyzed:result.pagesAnalyzed};
  }catch(e){await c.query('ROLLBACK').catch(()=>{});throw e}finally{c.release()}
});

handlers.set('product.match',async id=>{
  const c=await pool.connect();
  try{
    const job=await receiptPayload(id);
    const result=await matchProduct(c,job.payload);
    await c.query('BEGIN');
    await c.query(`INSERT INTO app.outbox_events(event_key,aggregate_type,aggregate_id,event_type,payload,queue) VALUES($1,'product',$2,'product.summary.changed',$3,'intelligence') ON CONFLICT(event_key) DO NOTHING`,[`product-summary:${job.payload.productId}:${job.payload.productVersionId}`,job.payload.productId,{productId:job.payload.productId}]);
    await c.query('COMMIT');
    return result;
  }catch(e){await c.query('ROLLBACK').catch(()=>{});throw e}finally{c.release()}
});

async function crawlSource(sourceKey:string,limit:number){
  const adapter=sourceRegistry.get(sourceKey);
  if(!adapter)throw new Error(`ADAPTER_NOT_INSTALLED:${sourceKey}`);
  const source=await pool.query(`SELECT id,status FROM app.sources WHERE key=$1`,[sourceKey]);
  if(!source.rowCount||source.rows[0].status!=='active')return{sourceKey,skipped:true};
  const sourceId=source.rows[0].id as string;
  const items=await crawler.sample(sourceKey,limit);
  let conversations=0,signals=0;
  for(const normalized of items){
    let conversationId='';
    const saveClient=await pool.connect();
    try{
      await saveClient.query('BEGIN');
      const saved=await persistConversation(saveClient,sourceId,normalized);
      conversationId=saved.id; conversations++;
      await saveClient.query('COMMIT');
    }catch(e){
      await saveClient.query('ROLLBACK').catch(()=>{});
      log.warn('crawl.item_persist_failed',{sourceKey,error:e instanceof Error?e.message:String(e)},client);
      continue;
    }finally{saveClient.release()}

    try{
      const quick=quickSignalCandidate(`${normalized.title}\n${normalized.bodyText}`);
      if(!quick.keep)continue;
      let sig=classifyDeterministically(normalized);
      if(process.env.AI_PROVIDER==='gemini')sig=await ai.classifySignal({conversationId,url:normalized.canonicalUrl,text:`${normalized.title}\n${normalized.bodyText}`,publishedAt:normalized.publishedAt})??sig;
      if(!sig)continue;
      sig={...sig,conversationId} as Signal;
      const vectors=await ai.embed([`${sig.summary} ${sig.evidence.map(x=>x.excerpt).join(' ')}`]);
      const vec=vectors[0]??[];
      const signalClient=await pool.connect();
      try{
        await signalClient.query('BEGIN');
        const signalId=await persistSignal(signalClient,conversationId,sig,process.env.AI_PROVIDER??'deterministic');
        if(vec.length){
          const inputHash=crypto.createHash('sha256').update(`${sig.summary}|${sig.publishedAt}`).digest('hex');
          await signalClient.query(`INSERT INTO app.embeddings(owner_type,signal_id,provider,model,dimension,embedding,input_hash,embedding_version) VALUES('signal',$1,$2,$3,$4,$5::vector,$6,'1') ON CONFLICT DO NOTHING`,[signalId,process.env.AI_PROVIDER??'deterministic',process.env.EMBEDDING_MODEL??'deterministic-64',vec.length,`[${vec.join(',')}]`,inputHash]);
        }
        await signalClient.query('COMMIT'); signals++;
      }catch(e){await signalClient.query('ROLLBACK').catch(()=>{});throw e}finally{signalClient.release()}
    }catch(e){
      log.warn('crawl.signal_failed',{sourceKey,conversationId,error:e instanceof Error?e.message:String(e)},client);
    }
  }
  return{sourceKey,conversations,signals};
}


async function discoverSourceCandidates(){
  const recent=await pool.query(`
    SELECT DISTINCT x.link
    FROM app.conversations c
    CROSS JOIN LATERAL jsonb_array_elements_text(coalesce(c.metadata->'outboundUrls','[]'::jsonb)) AS x(link)
    WHERE c.deleted_at IS NULL AND c.last_seen_at > now()-interval '30 days'
    LIMIT 5000
  `);
  const existing=await pool.query(`SELECT base_url FROM app.sources`);
  const known=new Set(existing.rows.map(r=>{try{return new URL(String(r.base_url)).hostname.replace(/^www\./,'')}catch{return''}}));
  const candidates=new Map<string,string>();
  for(const row of recent.rows){
    try{
      const u=new URL(String(row.link));
      if(!['http:','https:'].includes(u.protocol))continue;
      const host=u.hostname.toLowerCase().replace(/^www\./,'');
      if(!host||known.has(host)||host.endsWith('github.com')||host.endsWith('gitlab.com')||host.endsWith('stackoverflow.com')||host.endsWith('dev.to')||host.endsWith('bsky.app'))continue;
      candidates.set(host,u.origin);
    }catch{}
  }
  let inserted=0;
  const c=await pool.connect();
  try{
    await c.query('BEGIN');
    for(const [host,origin] of [...candidates].slice(0,100)){
      const key=`candidate-${host.replace(/[^a-z0-9]+/g,'-')}`.slice(0,80).replace(/-+$/,'');
      const r=await c.query(`INSERT INTO app.sources(key,name,kind,status,base_url,adapter_name,adapter_version,requires_credential,requires_external_authorization,discovered_at) VALUES($1,$2,'html','review_required',$3,'generic-candidate','1',false,false,now()) ON CONFLICT(key) DO NOTHING RETURNING id`,[key,host,origin]);
      inserted+=r.rowCount??0;
    }
    await c.query('COMMIT');
  }catch(e){await c.query('ROLLBACK').catch(()=>{});throw e}finally{c.release()}
  return{examined:recent.rowCount,candidates:candidates.size,inserted};
}
handlers.set('source.discover',async()=>discoverSourceCandidates());

handlers.set('source.sample',async id=>{
  const job=await receiptPayload(id); const p=job.payload;
  return crawlSource(String(p.sourceKey),Math.min(200,Math.max(1,Number(p.limit??100))));
});

async function crawlCycle(receiptId:string,continuous=false){
  const c=await pool.connect(); let runId=''; let limitPerSource=continuous?80:250;
  try{
    await c.query('BEGIN'); await ensureBuiltInSources(c);
    const job=await receiptPayload(receiptId);
    limitPerSource=Math.min(1000,Math.max(1,Number(job.payload?.limitPerSource??limitPerSource)));
    const run=await c.query(`INSERT INTO app.crawl_runs(workspace_id,mode,status,requested_by_user_id,configuration,started_at,heartbeat_at) VALUES($1,$2,'running',NULL,$3,now(),now()) RETURNING id`,[job.workspace_id??null,continuous?'continuous':'seed',{receiptId}]);
    runId=run.rows[0].id; await c.query('COMMIT');
  }catch(e){await c.query('ROLLBACK').catch(()=>{});throw e}finally{c.release()}
  const active=await pool.query(`SELECT key FROM app.sources WHERE status='active' AND key=ANY($1::text[])`,[[...sourceRegistry.list().map(a=>a.id)]]);
  let discovered=0,qualified=0,failed=0;
  for(const row of active.rows){
    try{const result:any=await crawlSource(row.key,limitPerSource);discovered+=Number(result.conversations??0);qualified+=Number(result.signals??0)}
    catch(e){failed++;log.warn('crawl.source_failed',{sourceKey:row.key,error:e instanceof Error?e.message:String(e)},client)}
    await pool.query(`UPDATE app.crawl_runs SET discovered_items=$2,normalized_items=$2,qualified_signals=$3,failed_items=$4,heartbeat_at=now() WHERE id=$1`,[runId,discovered,qualified,failed]);
  }
  await pool.query(`UPDATE app.crawl_runs SET status='succeeded',finished_at=now(),updated_at=now() WHERE id=$1`,[runId]);
  return {runId,discovered,qualified,failed};
}
handlers.set('crawl.seed',id=>crawlCycle(id,false));
handlers.set('crawl.continuous',id=>crawlCycle(id,true));

handlers.set('opportunity.draft',async id=>{
  const r=await pool.query(`SELECT j.payload,o.*,s.summary,s.signal_type,s.confidence,s.intent_score,s.urgency_score,s.authority_score,s.budget_score,s.negative_penalty,s.reason_codes,s.published_at,c.body_text,c.canonical_url,pv.website_url,pv.name,pv.tagline,pv.summary product_summary,pv.categories,pv.features,pv.value_propositions,pv.pricing,icp.roles,icp.pains,icp.intents,icp.firmographics,icp.exclusions,se.excerpt,se.source_url FROM app.crawl_jobs j JOIN app.opportunities o ON o.id=(j.payload->>'opportunityId')::uuid JOIN app.signals s ON s.id=o.signal_id JOIN app.conversations c ON c.id=s.conversation_id JOIN app.product_versions pv ON pv.id=o.product_version_id JOIN app.icp_profiles icp ON icp.product_version_id=pv.id JOIN LATERAL(SELECT * FROM app.signal_evidence WHERE signal_id=s.id ORDER BY confidence DESC LIMIT 1)se ON true WHERE j.id=$1`,[id]);
  if(!r.rowCount) throw new Error('OPPORTUNITY_NOT_FOUND'); const x=r.rows[0];
  const product:ProductAnalysis={name:x.name,websiteUrl:x.website_url,tagline:x.tagline??'',summary:x.product_summary??'',categories:x.categories??[],features:Array.isArray(x.features)?x.features:[],valuePropositions:Array.isArray(x.value_propositions)?x.value_propositions:[],pricing:x.pricing??{},competitors:[],icp:{roles:x.roles??[],industries:x.firmographics?.industries??[],companySizes:x.firmographics?.companySizes??[],geographies:x.firmographics?.geographies??[],pains:x.pains??[],intents:x.intents??[],exclusions:x.exclusions?.items??[]},customerLanguage:[],confidence:.8,evidence:[]};
  const signal:Signal={id:x.signal_id,conversationId:x.signal_id,type:x.signal_type,summary:x.summary,confidence:Number(x.confidence),intentScore:Number(x.intent_score),urgencyScore:Number(x.urgency_score),authorityScore:Number(x.authority_score),budgetScore:Number(x.budget_score),negativePenalty:Number(x.negative_penalty),reasonCodes:x.reason_codes??[],evidence:[{excerpt:x.excerpt,sourceUrl:x.source_url,confidence:.9}],publishedAt:new Date(x.published_at).toISOString()};
  return ai.draftReply({product,signal,context:x.body_text});
});

handlers.set('projection.refresh',async id=>{
  const job=await receiptPayload(id); const p=job.payload??{};
  const c=await pool.connect(); try{
    if(p.opportunityId) await refreshOpportunity(c,String(p.opportunityId));
    if(p.productId) await refreshProductSummary(c,String(p.productId));
    if(p.publicProfileId) await refreshPublicProfile(c,String(p.publicProfileId));
  }finally{c.release()}
  return {refreshed:true};
});

handlers.set('maintenance.cleanup',async()=>{
  const c=await pool.connect(); const schedulerClient={type:'scheduler' as const,name:'scheduler'};
  try{
    const counts={deleted:0,expired:0,repaired:0,compressed:0,quarantined:0};
    log.info('cleanup.started',{},schedulerClient);
    const a=await c.query(`DELETE FROM app.auth_verification_tokens WHERE expires<now()-interval '1 day'`); counts.expired+=a.rowCount??0;
    const b=await c.query(`DELETE FROM app.outbox_events WHERE processed_at<now()-interval '7 days'`); counts.deleted+=b.rowCount??0;
    const d=await c.query(`DELETE FROM app.fetch_attempts WHERE created_at<now()-interval '30 days' AND outcome IN('success','not_modified')`); counts.deleted+=d.rowCount??0;
    const total=Object.values(counts).reduce((sum,n)=>sum+n,0);
    if(total>0) await c.query(`INSERT INTO app.audit_events(actor_type,category,action,severity,action_counts) VALUES('scheduler','maintenance','maintenance.cleanup','info',$1)`,[counts]);
    log.info('cleanup.finished',counts,schedulerClient); return counts;
  }finally{c.release()}
});

async function transition(id:string,status:string,result?:Record<string,unknown>,error?:unknown){
  const leaseSeconds=Math.max(30,Number(process.env.JOB_LEASE_SECONDS??300));
  const running=status==='running'; const terminal=['succeeded','failed','dead_letter','cancelled'].includes(status);
  await pool.query(`UPDATE app.crawl_jobs SET
    status=$2,
    progress=CASE WHEN $2='succeeded' THEN 1 ELSE progress END,
    result_summary=coalesce($3,result_summary),
    last_error_code=$4,
    last_error_retryable=$5,
    attempts_started=CASE WHEN $2='running' THEN attempts_started+1 ELSE attempts_started END,
    lease_owner=CASE WHEN $2='running' THEN $6 ELSE NULL END,
    lease_expires_at=CASE WHEN $2='running' THEN now()+($7::text||' seconds')::interval ELSE NULL END,
    heartbeat_at=CASE WHEN $2='running' THEN now() ELSE heartbeat_at END,
    started_at=CASE WHEN $2='running' THEN coalesce(started_at,now()) ELSE started_at END,
    finished_at=CASE WHEN $8 THEN now() ELSE finished_at END,
    updated_at=now()
    WHERE id=$1`,[id,status,result??null,error instanceof Error?error.message.slice(0,100):null,status==='retry_scheduled',`worker-${role}:${process.pid}`,leaseSeconds,terminal]);
}

const roleJobs:Record<string,string[]>={
  discovery:['source.discover'],
  http:['source.sample','crawl.seed','crawl.continuous'],
  browser:['product.analyze'],
  ai:['opportunity.draft'],
  jobs:['product.match','projection.refresh','maintenance.cleanup'],
  scheduler:[],
};

async function registerWorkers(){
  for(const name of roleJobs[role]??[]){
    await boss.createQueue(name);
    await boss.work(name,{teamSize:1,teamConcurrency:name==='source.sample'?2:1},async jobs=>{
      for(const job of jobs){
        const receiptId=String((job.data as any).receiptId??job.id);
        await transition(receiptId,'running');
        try{
          const result=await handlers.get(name)!(receiptId);
          await transition(receiptId,'succeeded',result??{});
        }catch(e){
          const state=await pool.query(`SELECT attempts_started,max_attempts FROM app.crawl_jobs WHERE id=$1`,[receiptId]);
          const attempts=Number(state.rows[0]?.attempts_started??1), max=Number(state.rows[0]?.max_attempts??1);
          const status=attempts>=max?'dead_letter':'retry_scheduled';
          log.error('job.failed',{jobType:name,receiptId,attempts,max,status,error:e instanceof Error?e.message:String(e)},client);
          await transition(receiptId,status,undefined,e);
          if(status==='retry_scheduled') throw e;
        }
      }
    });
  }
}

async function relay(){
  while(true){
    const c=await pool.connect();
    try{
      await c.query('BEGIN');
      const events=await c.query(`SELECT id,event_key,payload FROM app.outbox_events WHERE processed_at IS NULL AND dead_lettered_at IS NULL AND available_at<=now() AND(locked_until IS NULL OR locked_until<now()) ORDER BY id LIMIT 100 FOR UPDATE SKIP LOCKED`);
      for(const event of events.rows){
        const jobType=event.payload?.jobType as string|undefined;
        if(jobType){
          const state=await c.query(`SELECT max_attempts,status FROM app.crawl_jobs WHERE id=$1`,[event.payload.jobId]);
          if(!state.rowCount) throw new Error(`OUTBOX_RECEIPT_MISSING:${event.payload.jobId}`);
          await boss.createQueue(jobType);
          await boss.send(jobType,{receiptId:event.payload.jobId},{id:event.payload.jobId,retryLimit:Math.max(0,Number(state.rows[0].max_attempts)-1),retryDelay:2,retryBackoff:true});
          await c.query(`UPDATE app.crawl_jobs SET status=CASE WHEN status='accepted' THEN 'queued' ELSE status END,queued_at=coalesce(queued_at,now()),updated_at=now() WHERE id=$1`,[event.payload.jobId]);
        }else if(event.payload?.opportunityId||event.payload?.productId||event.payload?.publicProfileId){
          await boss.createQueue('projection.refresh');
          const canonical=`projection:${event.event_key}`;
          const receipt=await c.query(`INSERT INTO app.crawl_jobs(id,canonical_key,job_type,queue,resource_class,estimated_work_units,max_attempts,status,payload,origin_client) VALUES($1,$2,'projection.refresh','intelligence','orchestration',.2,10,'queued',$3,$4) ON CONFLICT(canonical_key) DO UPDATE SET updated_at=now() RETURNING id`,[crypto.randomUUID(),canonical,event.payload,{type:'worker',name:'outbox-relay'}]);
          const receiptId=receipt.rows[0].id as string;
          await boss.send('projection.refresh',{receiptId},{id:receiptId,retryLimit:9,retryDelay:1,retryBackoff:true});
        }
        await c.query(`UPDATE app.outbox_events SET processed_at=now(),locked_by=NULL,locked_until=NULL WHERE id=$1`,[event.id]);
      }
      await c.query('COMMIT');
    }catch(e){await c.query('ROLLBACK').catch(()=>{});log.error('outbox.relay_failed',{error:e instanceof Error?e.message:String(e)},client)}finally{c.release()}
    await new Promise(r=>setTimeout(r,Number(process.env.OUTBOX_POLL_INTERVAL_MS??500)));
  }
}

async function scheduleJob(jobType:'maintenance.cleanup'|'crawl.continuous'|'source.discover',canonicalKey:string,queue:'maintenance'|'fresh'|'discovery'){
  const c=await pool.connect();
  try{
    await c.query('BEGIN');
    const receipt=await c.query(`INSERT INTO app.crawl_jobs(id,canonical_key,job_type,queue,resource_class,estimated_work_units,max_attempts,status,payload,origin_client) VALUES($1,$2,$3,$4,'orchestration',1,5,'accepted','{}',$5) ON CONFLICT(canonical_key) DO UPDATE SET updated_at=now() RETURNING id`,[crypto.randomUUID(),canonicalKey,jobType,queue,{type:'scheduler',name:'scheduler'}]);
    const id=receipt.rows[0].id as string;
    await c.query(`INSERT INTO app.outbox_events(event_key,aggregate_type,aggregate_id,event_type,payload,queue) VALUES($1,'crawl_job',$2,'job.accepted',$3,$4) ON CONFLICT(event_key) DO NOTHING`,[`job.accepted:${canonicalKey}`,id,{jobId:id,jobType},queue]);
    await c.query('COMMIT');
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

function startScheduler(){
  if(process.env.SCHEDULER_ENABLED!=='true') return;
  const timezone=process.env.SCHEDULER_TIMEZONE??'UTC';
  cron.schedule('17 * * * *',()=>scheduleJob('maintenance.cleanup',`maintenance.cleanup:${new Date().toISOString().slice(0,13)}`,'maintenance').catch(e=>log.error('scheduler.cleanup_failed',{error:String(e)},{type:'scheduler',name:'scheduler'})),{timezone});
  cron.schedule('23 3 * * *',()=>scheduleJob('source.discover',`source.discover:${new Date().toISOString().slice(0,10)}`,'discovery').catch(e=>log.error('scheduler.discovery_failed',{error:String(e)},{type:'scheduler',name:'scheduler'})),{timezone});
  cron.schedule('*/15 * * * *',()=>scheduleJob('crawl.continuous',`crawl.continuous:${new Date().toISOString().slice(0,16).replace(/.$/,'0')}`,'fresh').catch(e=>log.error('scheduler.crawl_failed',{error:String(e)},{type:'scheduler',name:'scheduler'})),{timezone});
}

async function main(){
  boss.on('error',e=>log.error('pgboss.error',{error:e.message},client));
  await boss.start();
  if(role!=='scheduler') await registerWorkers();
  if(role==='scheduler') startScheduler();
  if(role==='jobs') relay().catch(e=>log.fatal('relay.fatal',{error:String(e)},client));
  log.info('worker.started',{role,pid:process.pid},client);
}
main().catch(e=>{log.fatal('worker.fatal',{error:e instanceof Error?e.message:String(e)},client);process.exit(1)});
async function stop(){await closeMatchingPool().catch(()=>{});await boss.stop({graceful:true,timeout:10000});await pool.end();process.exit(0)}
process.on('SIGTERM',stop);process.on('SIGINT',stop);
