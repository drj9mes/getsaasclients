import crypto from 'node:crypto';
import type pg from 'pg';
import type { ProductAnalysis } from '@saasclients/contracts';
import { crawlHtmlPages } from '@saasclients/crawler';
import { createAiProvider } from '@saasclients/ai';
import { slugify, canonicalProductPath } from '@saasclients/seo';

const ai=createAiProvider();
const PATH_HINTS=['pricing','features','product','use-cases','usecases','solutions','integrations','customers','docs','about','security','compare','alternative','versus','case-stud'];

type ProductPayload={url:string;workspaceId:string;userId?:string};
type PreparedProduct={
  rootUrl:string;
  domain:string;
  slug:string;
  inputHash:string;
  analysis:ProductAnalysis;
  pagesAnalyzed:number;
  embedding:number[];
};

/** Network and AI phase. No database transaction is held while this runs. */
export async function prepareProductAnalysis(payload:ProductPayload):Promise<PreparedProduct>{
  const root=new URL(payload.url);
  const ua=process.env.CRAWLER_USER_AGENT ?? 'GetSaaSClientsBot/0.1 (+https://getsaasclients.com)';
  const first=await crawlHtmlPages([root.toString()],{maxPages:1,maxConcurrency:1,browserFallback:true,userAgent:ua});
  if(!first.length||first[0]!.text.length<40)throw new Error('PRODUCT_WEBSITE_UNREADABLE');
  const candidates=[...new Set(first[0]!.links.filter(link=>{
    try{const u=new URL(link);return u.hostname===root.hostname&&PATH_HINTS.some(h=>u.pathname.toLowerCase().includes(h))}catch{return false}
  }))].slice(0,14);
  const rest=candidates.length?await crawlHtmlPages(candidates,{maxPages:14,maxConcurrency:4,browserFallback:true,userAgent:ua}):[];
  const pages=[...first,...rest].slice(0,15).map(p=>({url:p.url,text:`TITLE: ${p.title}\n${p.text}`.slice(0,250000)}));
  const analysis=await ai.analyzeProduct({url:root.toString(),pages});
  const domain=root.hostname.replace(/^www\./,'');
  const slug=slugify(analysis.name);
  const inputHash=crypto.createHash('sha256').update(JSON.stringify({analysis,pages:pages.map(p=>[p.url,crypto.createHash('sha256').update(p.text).digest('hex')])})).digest('hex');
  const vectors=await ai.embed([`${analysis.summary} ${analysis.icp.pains.join(' ')} ${analysis.features.join(' ')}`]);
  return{rootUrl:root.toString(),domain,slug,inputHash,analysis,pagesAnalyzed:pages.length,embedding:vectors[0]??[]};
}

/** Persistence phase. Caller owns the short transaction and outbox write. */
export async function persistProductAnalysis(c:pg.PoolClient,payload:ProductPayload,prepared:PreparedProduct){
  const{rootUrl,domain,slug,inputHash,analysis,embedding}=prepared;
  const existing=await c.query(`SELECT id FROM app.products WHERE workspace_id=$1 AND domain=$2 FOR UPDATE`,[payload.workspaceId,domain]);
  let productId:string;
  if(existing.rowCount){
    productId=existing.rows[0].id;
    await c.query(`UPDATE app.products SET name=$2,canonical_url=$3,status='active',updated_at=now() WHERE id=$1`,[productId,analysis.name,rootUrl]);
    await c.query(`UPDATE app.product_versions SET is_current=false WHERE product_id=$1 AND is_current`,[productId]);
  }else{
    const p=await c.query(`INSERT INTO app.products(workspace_id,slug,name,canonical_url,domain,status,created_by_user_id) VALUES($1,$2,$3,$4,$5,'active',$6) RETURNING id`,[payload.workspaceId,slug,analysis.name,rootUrl,domain,payload.userId??null]);
    productId=p.rows[0].id;
  }
  const vno=await c.query(`SELECT coalesce(max(version_no),0)+1 n FROM app.product_versions WHERE product_id=$1`,[productId]);
  const pv=await c.query(`INSERT INTO app.product_versions(workspace_id,product_id,version_no,is_current,input_hash,analysis_status,website_url,name,tagline,summary,categories,features,value_propositions,pricing,competitor_hints,extraction_evidence,analyzer_version,analyzed_at,created_by_user_id) VALUES($1,$2,$3,true,$4,'ready',$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,'product-analyzer-v2',now(),$15) RETURNING id`,[
    payload.workspaceId,productId,vno.rows[0].n,inputHash,analysis.websiteUrl,analysis.name,analysis.tagline,analysis.summary,analysis.categories,analysis.features,analysis.valuePropositions,analysis.pricing,analysis.competitors,analysis.evidence,payload.userId??null,
  ]);
  await c.query(`UPDATE app.icp_profiles SET is_current=false WHERE product_id=$1 AND is_current`,[productId]);
  const ino=await c.query(`SELECT coalesce(max(version_no),0)+1 n FROM app.icp_profiles WHERE product_id=$1`,[productId]);
  await c.query(`INSERT INTO app.icp_profiles(workspace_id,product_id,product_version_id,version_no,is_current,firmographics,roles,pains,intents,keywords,exclusions,preferred_languages,created_by_user_id) VALUES($1,$2,$3,$4,true,$5,$6,$7,$8,$9,$10,ARRAY['en'],$11)`,[
    payload.workspaceId,productId,pv.rows[0].id,ino.rows[0].n,{industries:analysis.icp.industries,companySizes:analysis.icp.companySizes,geographies:analysis.icp.geographies},analysis.icp.roles,analysis.icp.pains,analysis.icp.intents,[...analysis.customerLanguage,...analysis.categories],{items:analysis.icp.exclusions},payload.userId??null,
  ]);
  if(embedding.length)await c.query(`INSERT INTO app.embeddings(workspace_id,owner_type,product_version_id,provider,model,dimension,embedding,input_hash,embedding_version) VALUES($1,'product_version',$2,$3,$4,$5,$6::vector,$7,'1') ON CONFLICT DO NOTHING`,[
    payload.workspaceId,pv.rows[0].id,process.env.AI_PROVIDER??'deterministic',process.env.EMBEDDING_MODEL??'deterministic-64',embedding.length,`[${embedding.join(',')}]`,inputHash,
  ]);
  const description=(analysis.summary||`${analysis.name} software`).slice(0,2000).padEnd(40,'.');
  const profile=await c.query(`INSERT INTO app.public_profiles(workspace_id,product_id,slug,status,title,description,content,canonical_path,noindex) VALUES($1,$2,$3,'draft',$4,$5,$6,$7,true) ON CONFLICT(workspace_id,product_id) DO UPDATE SET title=excluded.title,description=excluded.description,content=excluded.content,updated_at=now() RETURNING id`,[
    payload.workspaceId,productId,slug,analysis.name,description,analysis,canonicalProductPath(slug),
  ]);
  return{productId,productVersionId:pv.rows[0].id as string,publicProfileId:profile.rows[0].id as string,analysis,pagesAnalyzed:prepared.pagesAnalyzed};
}
