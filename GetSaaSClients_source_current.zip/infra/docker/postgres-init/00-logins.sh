#!/usr/bin/env bash
set -euo pipefail
required=(POSTGRES_API_PASSWORD POSTGRES_AUTH_PASSWORD POSTGRES_WORKER_PASSWORD POSTGRES_PGBOSS_PASSWORD POSTGRES_ADMIN_PASSWORD POSTGRES_MIGRATOR_PASSWORD)
for v in "${required[@]}"; do [[ -n "${!v:-}" ]] || { echo "$v is required" >&2; exit 1; }; done
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<SQL
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS vector;
DO \$\$ BEGIN
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_api') THEN CREATE ROLE saasclients_api NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_auth') THEN CREATE ROLE saasclients_auth NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_worker') THEN CREATE ROLE saasclients_worker NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_admin') THEN CREATE ROLE saasclients_admin NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_public') THEN CREATE ROLE saasclients_public NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_api_login') THEN CREATE ROLE saasclients_api_login LOGIN IN ROLE saasclients_api; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_auth_login') THEN CREATE ROLE saasclients_auth_login LOGIN IN ROLE saasclients_auth; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_worker_login') THEN CREATE ROLE saasclients_worker_login LOGIN IN ROLE saasclients_worker; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_admin_login') THEN CREATE ROLE saasclients_admin_login LOGIN IN ROLE saasclients_admin; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_pgboss_login') THEN CREATE ROLE saasclients_pgboss_login LOGIN; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='saasclients_migrator_login') THEN CREATE ROLE saasclients_migrator_login LOGIN; END IF;
END \$\$;
ALTER ROLE saasclients_api_login PASSWORD '${POSTGRES_API_PASSWORD}';
ALTER ROLE saasclients_auth_login PASSWORD '${POSTGRES_AUTH_PASSWORD}';
ALTER ROLE saasclients_worker_login PASSWORD '${POSTGRES_WORKER_PASSWORD}';
ALTER ROLE saasclients_admin_login PASSWORD '${POSTGRES_ADMIN_PASSWORD}';
ALTER ROLE saasclients_pgboss_login PASSWORD '${POSTGRES_PGBOSS_PASSWORD}';
ALTER ROLE saasclients_migrator_login PASSWORD '${POSTGRES_MIGRATOR_PASSWORD}';
ALTER DATABASE ${POSTGRES_DB} OWNER TO saasclients_migrator_login;
GRANT CONNECT ON DATABASE ${POSTGRES_DB} TO saasclients_api_login,saasclients_auth_login,saasclients_worker_login,saasclients_admin_login,saasclients_pgboss_login;
CREATE SCHEMA IF NOT EXISTS pgboss AUTHORIZATION saasclients_pgboss_login;
GRANT USAGE,CREATE ON SCHEMA pgboss TO saasclients_pgboss_login;
SQL
