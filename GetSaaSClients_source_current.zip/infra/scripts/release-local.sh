#!/usr/bin/env bash
set -euo pipefail
corepack enable
corepack prepare pnpm@10.15.0 --activate
if [[ ! -f pnpm-lock.yaml ]]; then pnpm install; else pnpm install --frozen-lockfile; fi
pnpm exec playwright install chromium
pnpm test:offline
pnpm lint
pnpm typecheck
pnpm test
pnpm build
docker compose up -d postgres
pnpm db:migrate
pnpm db:check
docker compose up -d
pnpm test:e2e
