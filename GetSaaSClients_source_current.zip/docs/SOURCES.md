# Source policy

GetSaaSClients stores a global public corpus once and matches it to tenant-scoped SaaS products. Access is policy-driven.

## MVP active adapter families

| Source | Access | Default transport | Notes |
|---|---|---|---|
| GitHub public issues | free/self-service key optional | official REST API | token raises legitimate quota; not mandatory |
| Hacker News | free/open | official Firebase API | public story/item evidence |
| Stack Exchange | free/self-service key optional | API v2.3 | attribution retained |
| Forem / DEV | free/open | official API | public articles/discussions |
| Bluesky | free/open | public AppView API | targeted query signals |
| GitLab public issues | free/open | official API | public issues |

Reddit and Meta are source records only: no network adapter is shipped. Activation requires feature flag, credential, recorded external authorization, scopes and health checks. X/Twitter, LinkedIn, private Facebook groups, Discord global scraping, Quora, G2/Capterra/Trustpilot scraping and paid contact databases are excluded.

## Admission sequence

`discovered -> policy_review -> sampled -> qualified -> approved -> canary -> active -> degraded/paused/revoked`

A source can be slowed/paused for low qualified-signal density, high duplicate rate, persistent 403/429, policy changes or repeated founder rejection.

Generic web discovery must prefer API/feed/sitemap, then permitted static HTML, and only then bounded Playwright. No blocking/circumvention is allowed.
