# Security model

- SSRF: only HTTP/HTTPS; reject credentials in URLs; resolve DNS; block private/loopback/link-local/multicast; revalidate redirects.
- Crawling: robots-aware generic crawling; official API/feed first; no CAPTCHA/auth/paywall/rate-limit bypass or stealth proxy rotation.
- Auth: Auth.js database sessions; Google/GitHub/magic link only; no production startup without a real provider.
- CSRF/origin: mutation routes require configured browser Origin after Auth.js routes.
- Database: five NOLOGIN runtime groups with distinct login accounts; FORCE RLS on tenant data; separate pg-boss schema/login and migration login.
- Credentials: encrypted DB, env reference or external file reference; secrets never accepted as ordinary CLI command-line values.
- AI: production deterministic provider prohibited; hard budget and deterministic prefiltering before LLM calls.
- Work: accepted heavy commands are durable; no unbounded in-memory queue is source of truth.
- CPU: reusable bounded `worker_threads` pool receives only bounded DTOs; DB/network/secrets stay in parent process.
