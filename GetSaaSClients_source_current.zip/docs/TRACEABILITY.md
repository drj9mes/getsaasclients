# Production-plan traceability

| Requirement | Implementation | Primary validation |
|---|---|---|
| Strict TypeScript monorepo | `apps/*`, `packages/*`, root tsconfig/pnpm/turbo | `pnpm typecheck`, syntax gate |
| Express 5 API + Next.js web | `apps/api`, `apps/web` | build + E2E smoke |
| 40 truth tables + 5 projections | `packages/db/migrations`, Drizzle schema | `tests/offline/contracts.mjs`, `db:check` |
| Global corpus / tenant opportunities | corpus tables + `opportunities.workspace_id` | schema/RLS tests |
| Persist-first heavy work | `acceptJob`, outbox relay, pg-boss worker | job integration/crash tests |
| Gated Reddit/Meta | source registry records only; no adapters | source security audit |
| No paid sources | adapter `hardMonthlyCapUsd=0`; X excluded | source audit |
| HTTP/API first, Playwright fallback | crawler core + product analyzer | crawler unit tests/live source canary |
| SSRF/robots controls | `assertPublicHttpUrl`, `robotsAllows` | crawler/security tests |
| Evidence-required signals/opportunities | signal evidence schema + matcher/projection | unit/DB checks |
| Founder correction/versioning | PATCH product + `ProductEditor` | API/E2E |
| Human-controlled outreach | draft endpoint/UI; no send adapter | source/security audit |
| Fixed mono-host services | `docker-compose.yml` | contracts + live burst |
| Bounded CPU thread pool | runtime-control CPU pool | unit + overload/live tests |
| JSONL log routing | observability package | unit/soak |
| No-op cleanup has no DB history | worker cleanup | integration + maintenance test |
| Public SaaS SEO profiles | `/saas/[slug]`, sitemap, publishing route | Next build/SEO tests |
| Acquisition stories | story routes/UI/public page | E2E + consent test |
| CLI control plane | `packages/cli` | CLI smoke |
| Gate A/B | offline + integration/golden suites | workflows |
| 7-day/30-day soak + commercial Gate 0 | runbook/live environment | not synthetically replaceable |
