# Data policy

- Keep normalized evidence needed to explain an opportunity; discard raw HTML after bounded temporary retention unless explicitly retained as a lawful fixture.
- Never republish complete third-party articles/reviews when a short evidence excerpt and source URL suffice.
- Keep public author identity minimal and source-scoped; do not enrich personal emails in MVP.
- A public author is not automatically a prospect. Negative signals such as `no vendors`, educational-only questions, already-resolved threads, sensitive/vulnerable situations and policy-prohibited contexts must suppress outreach recommendations.
- Source edits/removals propagate through revisit/tombstone workflows.
- Deletion requests are durable and open requests are unique per target.
- Tenant-private data is protected by workspace-scoped repositories plus PostgreSQL FORCE RLS.
- Raw successful fetches default to 24 hours; delivered outbox 7 days; successful receipts/fetch attempts 30 days; failed/parser diagnostics 90 days; security audit 180 days; tombstones at least 365 days.
