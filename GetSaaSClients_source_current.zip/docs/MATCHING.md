# Matching contract

Pipeline: deterministic negative/intent filter -> structured classification -> FTS/vector retrieval -> deterministic score -> bounded CPU-thread scoring/rerank -> diversity -> evidence-backed opportunity.

Initial score:

```text
0.22 problem_fit
+ 0.18 icp_fit
+ 0.15 intent
+ 0.10 urgency
+ 0.10 recency
+ 0.08 source_trust
+ 0.07 reachability
+ 0.05 evidence_quality
+ 0.05 model_confidence
- negative_penalty
```

Every displayed opportunity must include a source URL, exact evidence excerpt, human-readable reasons and a potential mismatch/reservation when applicable. A high score never grants permission to message someone automatically.

Offline Gate-B target: P@10 >= .75, P@20 >= .65, nDCG@10 >= .75, Recall@50 >= .70. Final release also requires human double-annotation and Cohen's kappa >= .65 on the real golden set.
