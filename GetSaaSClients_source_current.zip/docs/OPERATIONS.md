# Operations

The mono-host deployment uses fixed containers: `postgres`, `api`, `web`, `worker-discovery`, `worker-http`, `worker-browser`, `worker-ai`, `worker-jobs`, `scheduler`, `caddy`. Docker is a cgroup guardrail, not a request-time autoscaler.

## Durable work

Heavy API commands persist `crawl_jobs` + `outbox_events` in one PostgreSQL transaction before returning `202`. pg-boss is transport, not application truth. At-least-once delivery plus idempotent canonical keys is the guarantee.

## Priority

`interactive > fresh > intelligence > discovery > backfill > maintenance`. Under pressure, pause backfill/discovery before user/fresh work.

## Logs

`logs/<process>/<process>-events|warn|error|fatal-YYYY-MM-DD.jsonl`. Warn/error/fatal records require an explicit originating client; scheduled work uses `client.type=scheduler`.

## Cleanup

`node-cron` only provides scheduler timing. Cleanup is a durable singleton job. A no-op writes JSONL start/finish only and creates no business/audit row. A real action creates one aggregated audit record, not one row per deletion.

## Backups

Use `saasclients backup create --verify`; restore only into an explicitly named non-active database and verify before production recovery.
