# GetSaaSClients

**Find the people who need what you built.**

GetSaaSClients is a self-hostable SaaS acquisition engine. A founder submits a public SaaS URL, confirms the automatically extracted product/ICP model, and receives evidence-backed opportunities from a shared public demand-signal corpus. The founder remains in control of every outreach action; the MVP does not auto-spam communities or cold-email people.

## What ships in this repository

- Next.js founder application and public `/saas/[slug]` software profiles.
- Express 5 REST API + resumable job SSE.
- Auth.js database sessions with Google, GitHub and SMTP magic-link providers.
- PostgreSQL 17 + pgvector + FTS/pg_trgm.
- Exactly 40 application truth tables and 5 reconstructible read models.
- Durable receipt/outbox/pg-boss job delivery; heavy HTTP requests return `202` only after persistence.
- TypeScript crawler library and CLI.
- Free/open MVP adapters: GitHub, Hacker News, Stack Exchange, Forem/DEV, Bluesky and GitLab.
- Reddit/Meta data access remains gated/inert until credentials **and** a recorded external authorization are present. X/Twitter is excluded from MVP.
- Cheerio/HTTP-first crawling with robots/SSRF protections and bounded Playwright fallback.
- Deterministic prefilter/dedupe, Gemini-backed classification/embedding/reranking adapters, evidence-required matching and founder feedback loop.
- Bounded caches/semaphores, prewarmed CPU worker-thread pool, fixed Docker service topology and synthetic/live overload tests.
- Public SaaS profile + founder-approved acquisition story SEO surfaces and dynamic sitemap.

## Bootstrap

Target runtime is Node.js 24 LTS, pnpm 10.15, WSL2/Linux and Docker Compose.

```bash
corepack enable
corepack prepare pnpm@10.15.0 --activate
pnpm install
pnpm build
pnpm exec saasclients init --profile local-precision-7720
docker compose up -d postgres
pnpm db:migrate
pnpm exec saasclients doctor --json
docker compose up -d
```

The first successful online install creates `pnpm-lock.yaml`. Commit it immediately, then use `pnpm install --frozen-lockfile` for every release. A manual GitHub workflow is included to bootstrap/commit that lockfile from an official connected runner when the local environment cannot reach npm.

## Local URLs

- Web: `http://localhost:3000`
- API: `http://localhost:4000`
- Health: `http://localhost:4000/healthz`
- Caddy: `http://localhost` when `SAASCLIENTS_SITE_ADDRESS=:80`

## Seed and continuous crawl

```bash
pnpm exec saasclients discover seed --json
pnpm exec saasclients source list
pnpm exec saasclients crawl seed --resume
pnpm exec saasclients crawl status
pnpm exec saasclients crawl start --resume
```

Never activate a newly discovered source merely because it is publicly reachable. Run policy review, sample/canary and explicit activation first. Reddit/Meta require external authorization evidence in addition to normal source credentials.

## Validation

Offline, dependency-independent structural gate:

```bash
pnpm test:offline
```

Full installed gate:

```bash
pnpm lint
pnpm typecheck
pnpm test
pnpm build
pnpm db:migrate
pnpm db:check
pnpm test:e2e
```

The real overload gate is intentionally separate:

```bash
BURST_ARRIVALS=100000 BURST_CONCURRENCY=2000 TEST_BASE_URL=http://127.0.0.1:4000 pnpm test:load:live
```

## Production AI

`AI_PROVIDER=deterministic` is only for CI/local deterministic tests. Production workers refuse to start in that mode. Configure Gemini and a hard monthly budget:

```text
AI_PROVIDER=gemini
AI_API_KEY=...
AI_MONTHLY_BUDGET_USD=10
```

## Security boundaries

- Public HTTP/HTTPS only; DNS resolution blocks private, loopback, link-local and cloud-metadata targets.
- Redirect destinations are revalidated.
- `robots.txt` is checked before generic HTML/browser crawling.
- No CAPTCHA bypass, login bypass, paywall bypass, rotating identity/proxy evasion or paid data source in MVP.
- Browser state-changing requests require the configured application Origin.
- Runtime database identities inherit narrow NOLOGIN roles; ordinary API users never receive worker/admin/auth-token access.
- Secrets are omitted/redacted from application DTOs and JSONL logs.

Read `docs/OPERATIONS.md`, `docs/SOURCES.md`, `docs/DATA_POLICY.md`, `docs/MATCHING.md`, `docs/SECURITY.md` and `docs/TRACEABILITY.md` before production deployment.

## Release status

See `RELEASE_STATUS.md`. Calendar soak, live provider/OAuth/Gemini verification, human double-annotation, and the commercial dogfood gate are real-world release gates and cannot be substituted by synthetic tests.
